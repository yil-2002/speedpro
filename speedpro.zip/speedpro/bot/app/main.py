import asyncio
import logging
from aiogram import Bot, Dispatcher
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo
from aiogram.filters import CommandStart, Command
from aiogram.enums import ParseMode
from app.config import BOT_TOKEN, WEBAPP_URL, ADMIN_IDS

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher()

@dp.message(CommandStart())
async def start_handler(message: Message):
    keyboard = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔐 Личный кабинет", web_app=WebAppInfo(url=WEBAPP_URL))],
        [InlineKeyboardButton(text="💬 Поддержка", url="https://t.me/support")],
    ])

    await message.answer(
        f"👋 Привет, {message.from_user.first_name}!

"
        f"🚀 <b>SpeedPRO VPN</b> — быстрый и безопасный VPN.

"
        f"✅ VLESS + REALITY протокол
"
        f"✅ До 5 устройств
"
        f"✅ Оплата Telegram Stars

"
        f"Нажмите кнопку ниже, чтобы открыть приложение:",
        parse_mode=ParseMode.HTML,
        reply_markup=keyboard
    )

@dp.message(Command("admin"))
async def admin_handler(message: Message):
    if message.from_user.id not in ADMIN_IDS:
        await message.answer("⛔ Доступ запрещен")
        return
    await message.answer(
        "🔧 <b>Админ панель</b>

"
        "/stats — Статистика сервера
"
        "/users — Список пользователей
"
        "/gifts — Создать подарочные коды",
        parse_mode=ParseMode.HTML
    )

async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
