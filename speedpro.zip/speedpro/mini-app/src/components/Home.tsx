import { Link } from 'react-router-dom'

export default function Home({ user }: { user: any }) {
  return (
    <div className="home">
      <h1>🚀 SpeedPRO VPN</h1>
      <p>Привет, {user?.first_name || 'пользователь'}!</p>
      <div className="menu">
        <Link to="/tariffs" className="btn">📋 Тарифы</Link>
        <Link to="/profile" className="btn">👤 Профиль</Link>
      </div>
      <div className="features">
        <div>⚡ VLESS + REALITY</div>
        <div>🔒 Безопасность</div>
        <div>📱 До 5 устройств</div>
      </div>
    </div>
  )
}
