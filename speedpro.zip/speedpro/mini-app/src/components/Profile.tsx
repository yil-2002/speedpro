import { useState, useEffect } from 'react'

export default function Profile() {
  const [profile, setProfile] = useState<any>(null)

  useEffect(() => {
    const token = localStorage.getItem('token')
    fetch('/api/v1/me', {
      headers: {'Authorization': `Bearer ${token}`}
    })
    .then(r => r.json())
    .then(data => setProfile(data.data))
  }, [])

  if (!profile) return <div>Загрузка...</div>

  return (
    <div className="profile">
      <h2>👤 Профиль</h2>
      <div className="info">
        <p>Имя: {profile.first_name}</p>
        <p>Баланс: {profile.balance_stars} ⭐</p>
        <p>Баланс: {profile.balance_rub} ₽</p>
      </div>
      <div className="referral">
        <p>Реферальная ссылка:</p>
        <code>{profile.referral_code}</code>
      </div>
    </div>
  )
}
