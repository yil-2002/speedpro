import { useState } from 'react'

const tariffs = [
  {id: '1day', name: '1 день', price: 29, days: 1},
  {id: '1month', name: '1 месяц', price: 184, days: 30},
  {id: '12month', name: '12 месяцев', price: 1027, days: 365},
]

export default function Tariffs() {
  const [devices, setDevices] = useState(1)
  return (
    <div className="tariffs">
      <h2>📋 Тарифы</h2>
      <div className="devices-selector">
        <label>Устройства: {devices}</label>
        <input type="range" min="1" max="5" value={devices} onChange={e => setDevices(Number(e.target.value))} />
      </div>
      <div className="tariff-list">
        {tariffs.map(t => (
          <div key={t.id} className="tariff-card">
            <h3>{t.name}</h3>
            <div className="price">{t.price * devices} ⭐</div>
            <button className="buy-btn">Купить</button>
          </div>
        ))}
      </div>
    </div>
  )
}
