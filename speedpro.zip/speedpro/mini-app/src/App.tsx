import { useEffect, useState } from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Home from './components/Home'
import Profile from './components/Profile'
import Tariffs from './components/Tariffs'

declare global {
  interface Window {
    Telegram: any
  }
}

function App() {
  const [user, setUser] = useState<any>(null)

  useEffect(() => {
    const tg = window.Telegram.WebApp
    tg.ready()
    tg.expand()
    if (tg.initDataUnsafe?.user) {
      setUser(tg.initDataUnsafe.user)
    }
  }, [])

  return (
    <BrowserRouter>
      <div className="app">
        <Routes>
          <Route path="/" element={<Home user={user} />} />
          <Route path="/tariffs" element={<Tariffs />} />
          <Route path="/profile" element={<Profile />} />
        </Routes>
      </div>
    </BrowserRouter>
  )
}

export default App
