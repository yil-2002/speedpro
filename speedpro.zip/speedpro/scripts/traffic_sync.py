import asyncio
import httpx
import psycopg2
import os

DB_URL = os.getenv("DATABASE_URL", "postgresql://vpnuser:changeme@db:5432/vpnbot")
XRAY_URL = os.getenv("XRAY_PANEL_URL", "http://77.42.77.60:2053")

async def sync_traffic():
    conn = psycopg2.connect(DB_URL.replace("+asyncpg", ""))
    cur = conn.cursor()
    cur.execute("SELECT id, email FROM vpn_configs WHERE is_active = true")
    configs = cur.fetchall()

    async with httpx.AsyncClient() as client:
        for config_id, email in configs:
            pass

    cur.close()
    conn.close()

if __name__ == "__main__":
    asyncio.run(sync_traffic())
