#!/bin/bash
BACKUP_DIR="/backup"
mkdir -p $BACKUP_DIR
DATE=$(date +%Y%m%d_%H%M%S)
docker exec speedpro-db pg_dump -U vpnuser vpnbot > $BACKUP_DIR/vpnbot_$DATE.sql
echo "Backup created: $BACKUP_DIR/vpnbot_$DATE.sql"
