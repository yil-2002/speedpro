import psycopg2
import os
from datetime import datetime

DB_URL = os.getenv("DATABASE_URL", "postgresql://vpnuser:changeme@db:5432/vpnbot")

def check_expiry():
    conn = psycopg2.connect(DB_URL.replace("+asyncpg", ""))
    cur = conn.cursor()

    cur.execute("""
        UPDATE subscriptions 
        SET status = 'expired' 
        WHERE status = 'active' AND expires_at < NOW()
    """)

    conn.commit()
    cur.close()
    conn.close()
    print(f"[{datetime.now()}] Expired subscriptions updated")

if __name__ == "__main__":
    check_expiry()
