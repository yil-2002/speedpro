from fastapi import APIRouter
from app.schemas import TARIFFS, ResponseWrapper

router = APIRouter(prefix="/tariffs", tags=["tariffs"])

@router.get("", response_model=ResponseWrapper)
async def get_tariffs():
    return ResponseWrapper(data=[t.model_dump() for t in TARIFFS])
