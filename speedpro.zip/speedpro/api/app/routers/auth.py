from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.database import get_db
from app.models import User
from app.schemas import TelegramAuthRequest, AuthResponse, ResponseWrapper
from app.services.auth import create_access_token
import json
import hmac
import hashlib
from urllib.parse import parse_qs, unquote
from app.config import settings

router = APIRouter(prefix="/auth", tags=["auth"])


def validate_telegram_init_data(init_data: str) -> dict:
    try:
        parsed = parse_qs(init_data)
        data_check = {}
        for key, values in parsed.items():
            data_check[key] = unquote(values[0]) if values else ""

        hash_value = data_check.pop("hash", "")

        data_check_string = "
".join(
            f"{k}={v}" for k, v in sorted(data_check.items())
        )

        secret_key = hmac.new(
            b"WebAppData",
            settings.BOT_TOKEN.encode(),
            hashlib.sha256
        ).digest()

        check_hash = hmac.new(
            secret_key,
            data_check_string.encode(),
            hashlib.sha256
        ).hexdigest()

        if check_hash != hash_value:
            raise HTTPException(status_code=401, detail="Invalid init data")

        user_json = data_check.get("user", "{}")
        return json.loads(user_json)
    except Exception as e:
        raise HTTPException(status_code=401, detail=f"Auth error: {str(e)}")


@router.post("/telegram")
async def telegram_auth(
    request: TelegramAuthRequest,
    db: AsyncSession = Depends(get_db)
):
    user_data = validate_telegram_init_data(request.init_data)

    telegram_id = user_data.get("id")
    username = user_data.get("username")
    first_name = user_data.get("first_name")
    last_name = user_data.get("last_name")

    # Check if user exists
    result = await db.execute(select(User).where(User.id == telegram_id))
    user = result.scalar_one_or_none()

    if not user:
        # Create new user
        referral_code = f"{telegram_id}_{hashlib.md5(str(telegram_id).encode()).hexdigest()[:6]}"

        user = User(
            id=telegram_id,
            username=username,
            first_name=first_name,
            last_name=last_name,
            referral_code=referral_code,
            referred_by=int(request.referral_code.split("_")[0]) if request.referral_code and "_" in request.referral_code else None,
            is_admin=telegram_id in settings.admin_ids_list
        )
        db.add(user)
        await db.commit()
        await db.refresh(user)

    token = create_access_token({"sub": str(telegram_id)})

    return ResponseWrapper(
        data={
            "access_token": token,
            "token_type": "bearer"
        }
    )
