from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from app.database import get_db
from app.models import ServerStat, User, Subscription, VPNConfig
from app.schemas import ResponseWrapper
from app.services.auth import get_current_admin
from app.services.xray import xray_client
import psutil
from datetime import datetime

router = APIRouter(prefix="/admin", tags=["admin"])

@router.get("/server/stats", response_model=ResponseWrapper)
async def server_stats(current_user: dict = Depends(get_current_admin)):
    cpu = psutil.cpu_percent(interval=1)
    mem = psutil.virtual_memory()
    disk = psutil.disk_usage('/')

    xray_status = True
    try:
        await xray_client.get_server_status()
    except:
        xray_status = False

    return ResponseWrapper(data={
        "cpu_percent": cpu,
        "ram_percent": mem.percent,
        "ram_used_mb": mem.used / 1024 / 1024,
        "ram_total_mb": mem.total / 1024 / 1024,
        "disk_percent": disk.percent,
        "active_connections": 0,
        "xray_status": xray_status,
        "created_at": datetime.utcnow().isoformat()
    })

@router.get("/server/traffic", response_model=ResponseWrapper)
async def traffic_stats(
    current_user: dict = Depends(get_current_admin),
    db: AsyncSession = Depends(get_db)
):
    user_count = await db.execute(select(func.count(User.id)))
    total_users = user_count.scalar()

    active_count = await db.execute(
        select(func.count(Subscription.id)).where(Subscription.status == "active")
    )
    active_subs = active_count.scalar()

    return ResponseWrapper(data={
        "total_users": total_users,
        "active_subscriptions": active_subs,
        "daily_upload_gb": 0,
        "daily_download_gb": 0,
        "monthly_upload_gb": 0,
        "monthly_download_gb": 0
    })
