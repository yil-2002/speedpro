from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.database import get_db
from app.models import User, Payment, Subscription
from app.schemas import StarsPaymentRequest, PaymentSuccessRequest, ResponseWrapper, calculate_price, get_tariff
from app.services.auth import get_current_user
from app.config import settings
import uuid

router = APIRouter(prefix="/payments", tags=["payments"])

@router.post("/stars", response_model=ResponseWrapper)
async def create_stars_payment(
    request: StarsPaymentRequest,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    user_id = int(current_user["sub"])
    tariff = get_tariff(request.plan_type)
    if not tariff:
        raise HTTPException(status_code=400, detail="Invalid plan type")

    amount_rub, amount_stars = calculate_price(request.plan_type, request.devices_count)

    payment = Payment(
        id=uuid.uuid4(),
        user_id=user_id,
        amount_rub=amount_rub,
        amount_stars=amount_stars,
        payment_method="telegram_stars",
        status="pending"
    )
    db.add(payment)
    await db.commit()

    invoice = {
        "title": f"SpeedPRO VPN — {tariff.title_ru}",
        "description": f"{request.devices_count} устройств",
        "payload": str(payment.id),
        "currency": "XTR",
        "prices": [{"label": tariff.title_ru, "amount": amount_stars}]
    }

    return ResponseWrapper(data={
        "payment_id": str(payment.id),
        "invoice": invoice
    })

@router.post("/stars/success", response_model=ResponseWrapper)
async def stars_success(
    request: PaymentSuccessRequest,
    db: AsyncSession = Depends(get_db)
):
    result = await db.execute(select(Payment).where(Payment.id == request.payment_id))
    payment = result.scalar_one_or_none()
    if not payment:
        raise HTTPException(status_code=404, detail="Payment not found")

    payment.status = "success"
    payment.telegram_payment_charge_id = request.telegram_payment_charge_id
    await db.commit()

    return ResponseWrapper(data={"subscription_id": str(payment.subscription_id) if payment.subscription_id else None})
