from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.database import get_db
from app.models import User, Subscription, VPNConfig
from app.schemas import UserProfile, SubscriptionResponse, ResponseWrapper
from app.services.auth import get_current_user
from app.config import settings

router = APIRouter(prefix="/me", tags=["users"])


@router.get("", response_model=ResponseWrapper)
async def get_me(
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    user_id = int(current_user["sub"])
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()

    if not user:
        return ResponseWrapper(success=False, error="User not found")

    return ResponseWrapper(data={
        "id": user.id,
        "username": user.username,
        "first_name": user.first_name,
        "balance_rub": float(user.balance_rub),
        "balance_stars": user.balance_stars,
        "referral_code": user.referral_code,
        "created_at": user.created_at.isoformat()
    })


@router.get("/subscription", response_model=ResponseWrapper)
async def get_my_subscription(
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    user_id = int(current_user["sub"])
    result = await db.execute(
        select(Subscription).where(
            Subscription.user_id == user_id,
            Subscription.status == "active"
        )
    )
    subs = result.scalars().all()

    data = []
    for sub in subs:
        # Get config link
        config_result = await db.execute(
            select(VPNConfig).where(VPNConfig.subscription_id == sub.id)
        )
        config = config_result.scalar_one_or_none()

        data.append({
            "id": str(sub.id),
            "status": sub.status,
            "plan_type": sub.plan_type,
            "devices_count": sub.devices_count,
            "traffic_used_gb": sub.traffic_used_gb,
            "traffic_limit_gb": sub.traffic_limit_gb,
            "expires_at": sub.expires_at.isoformat(),
            "config_link": config.config_link if config else None
        })

    return ResponseWrapper(data=data)
