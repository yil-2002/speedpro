from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.database import get_db
from app.models import User, Referral
from app.schemas import ResponseWrapper
from app.services.auth import get_current_user
from app.config import settings

router = APIRouter(prefix="/referrals", tags=["referrals"])

@router.get("", response_model=ResponseWrapper)
async def get_referrals(
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    user_id = int(current_user["sub"])

    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one()

    ref_result = await db.execute(select(Referral).where(Referral.referrer_id == user_id))
    refs = ref_result.scalars().all()

    total_earned = sum(float(r.commission_rub) for r in refs if r.status == "paid")
    pending = sum(float(r.commission_rub) for r in refs if r.status == "pending")

    return ResponseWrapper(data={
        "invited_count": len(refs),
        "earned_rub": total_earned,
        "pending_rub": pending,
        "referral_link": f"https://t.me/{settings.BOT_TOKEN.split(':')[0]}?start={user.referral_code}",
        "referral_link_web": f"{settings.WEBAPP_BASE_URL}?ref={user.referral_code}"
    })
