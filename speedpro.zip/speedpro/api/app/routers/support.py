from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.database import get_db
from app.models import SupportTicket
from app.schemas import SupportTicketCreate, SupportTicketResponse, ResponseWrapper
from app.services.auth import get_current_user
import uuid
from datetime import datetime

router = APIRouter(prefix="/support", tags=["support"])

@router.post("", response_model=ResponseWrapper)
async def create_ticket(
    request: SupportTicketCreate,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    ticket = SupportTicket(
        id=uuid.uuid4(),
        user_id=int(current_user["sub"]),
        subject=request.subject,
        message=request.message
    )
    db.add(ticket)
    await db.commit()
    return ResponseWrapper(data={"ticket_id": str(ticket.id), "status": "open"})

@router.get("", response_model=ResponseWrapper)
async def get_tickets(
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    result = await db.execute(
        select(SupportTicket).where(SupportTicket.user_id == int(current_user["sub"]))
    )
    tickets = result.scalars().all()
    return ResponseWrapper(data=[{
        "id": str(t.id),
        "subject": t.subject,
        "message": t.message,
        "status": t.status,
        "admin_reply": t.admin_reply,
        "created_at": t.created_at.isoformat()
    } for t in tickets])
