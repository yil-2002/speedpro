from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.database import get_db
from app.models import GiftCode, User, Subscription
from app.schemas import GiftCreateRequest, GiftRedeemRequest, ResponseWrapper, get_tariff
from app.services.auth import get_current_user, get_current_admin
from app.config import settings
import uuid
import random
import string
from datetime import datetime, timedelta

router = APIRouter(prefix="/gifts", tags=["gifts"])

@router.post("", response_model=ResponseWrapper)
async def create_gift(
    request: GiftCreateRequest,
    current_user: dict = Depends(get_current_admin),
    db: AsyncSession = Depends(get_db)
):
    codes = []
    for _ in range(request.quantity):
        code = "GIFT_" + ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))
        gift = GiftCode(
            id=uuid.uuid4(),
            code=code,
            plan_type=request.plan_type,
            devices_count=request.devices_count,
            created_by=int(current_user["sub"])
        )
        db.add(gift)
        codes.append(code)
    await db.commit()
    return ResponseWrapper(data={"codes": codes})

@router.post("/redeem", response_model=ResponseWrapper)
async def redeem_gift(
    request: GiftRedeemRequest,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    result = await db.execute(select(GiftCode).where(GiftCode.code == request.code))
    gift = result.scalar_one_or_none()

    if not gift or gift.is_redeemed:
        raise HTTPException(status_code=400, detail="Invalid or already used code")

    user_id = int(current_user["sub"])
    gift.is_redeemed = True
    gift.redeemed_by = user_id
    gift.redeemed_at = datetime.utcnow()

    tariff = get_tariff(gift.plan_type)
    sub = Subscription(
        id=uuid.uuid4(),
        user_id=user_id,
        plan_type=gift.plan_type,
        devices_count=gift.devices_count,
        expires_at=datetime.utcnow() + timedelta(days=tariff.duration_days if tariff else 30)
    )
    db.add(sub)
    await db.commit()

    return ResponseWrapper(data={
        "status": "success",
        "message": "Code activated",
        "subscription_id": str(sub.id)
    })
