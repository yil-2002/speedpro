from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.database import get_db
from app.models import VPNConfig, Subscription, User
from app.schemas import ResponseWrapper
from app.services.auth import get_current_user
from app.services.xray import xray_client
import qrcode
import io
import base64

router = APIRouter(prefix="/vpn", tags=["vpn"])

@router.get("/config", response_model=ResponseWrapper)
async def get_configs(
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    user_id = int(current_user["sub"])
    result = await db.execute(select(VPNConfig).where(VPNConfig.user_id == user_id))
    configs = result.scalars().all()

    return ResponseWrapper(data=[{
        "id": str(c.id),
        "config_link": c.config_link,
        "server_address": c.server_address,
        "status": "active" if c.is_active else "inactive",
        "traffic_used": c.traffic_total,
        "traffic_limit": 100,
        "created_at": c.created_at.isoformat()
    } for c in configs])

@router.get("/config/{config_id}/qr", response_model=ResponseWrapper)
async def get_config_qr(
    config_id: str,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    result = await db.execute(
        select(VPNConfig).where(VPNConfig.id == config_id, VPNConfig.user_id == int(current_user["sub"]))
    )
    config = result.scalar_one_or_none()
    if not config:
        raise HTTPException(status_code=404, detail="Config not found")

    qr = qrcode.make(config.config_link)
    buffer = io.BytesIO()
    qr.save(buffer, format="PNG")
    img_str = base64.b64encode(buffer.getvalue()).decode()

    return ResponseWrapper(data={"qr_base64": img_str})

@router.delete("/config/{config_id}", response_model=ResponseWrapper)
async def delete_config(
    config_id: str,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    result = await db.execute(
        select(VPNConfig).where(VPNConfig.id == config_id, VPNConfig.user_id == int(current_user["sub"]))
    )
    config = result.scalar_one_or_none()
    if not config:
        raise HTTPException(status_code=404, detail="Config not found")

    config.is_active = False
    await db.commit()
    return ResponseWrapper(data={"deleted": True})
