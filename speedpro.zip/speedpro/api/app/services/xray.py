import httpx
import uuid
import json
from typing import Optional, Dict, Any, List
from app.config import settings


class XrayPanelClient:
    def __init__(self):
        self.base_url = settings.XRAY_PANEL_URL.rstrip("/")
        self.username = settings.XRAY_PANEL_USERNAME
        self.password = settings.XRAY_PANEL_PASSWORD
        self.cookie = None
        self.client = httpx.AsyncClient(verify=False, timeout=30.0)

    async def _login(self) -> bool:
        try:
            resp = await self.client.post(
                f"{self.base_url}/login",
                data={"username": self.username, "password": self.password}
            )
            if resp.status_code == 200:
                data = resp.json()
                if data.get("success"):
                    self.cookie = resp.cookies
                    return True
            return False
        except Exception as e:
            print(f"Xray login error: {e}")
            return False

    async def _request(self, method: str, endpoint: str, **kwargs) -> Optional[Dict]:
        if not self.cookie:
            if not await self._login():
                return None

        url = f"{self.base_url}{endpoint}"
        try:
            resp = await self.client.request(method, url, cookies=self.cookie, **kwargs)
            if resp.status_code == 401:
                # Re-login and retry
                if await self._login():
                    resp = await self.client.request(method, url, cookies=self.cookie, **kwargs)

            if resp.status_code == 200:
                try:
                    return resp.json()
                except:
                    return {"raw": resp.text}
            return None
        except Exception as e:
            print(f"Xray request error: {e}")
            return None

    async def get_inbounds(self) -> List[Dict]:
        data = await self._request("GET", "/panel/api/inbounds/list")
        if data and data.get("success"):
            return data.get("obj", [])
        return []

    async def get_inbound(self, inbound_id: int) -> Optional[Dict]:
        data = await self._request("GET", f"/panel/api/inbounds/get/{inbound_id}")
        if data and data.get("success"):
            return data.get("obj")
        return None

    async def add_client(self, inbound_id: int, email: str, uuid_str: str, 
                         expiry_days: int = 30, total_gb: int = 0) -> Optional[Dict]:
        # Get current inbound settings
        inbound = await self.get_inbound(inbound_id)
        if not inbound:
            return None

        settings_json = json.loads(inbound.get("settings", "{}"))
        clients = settings_json.get("clients", [])

        # Add new client
        new_client = {
            "id": uuid_str,
            "flow": "xtls-rprx-vision",
            "email": email,
            "limitIp": 0,
            "totalGB": total_gb * 1024 * 1024 * 1024 if total_gb > 0 else 0,
            "expiryTime": expiry_days * 86400000 if expiry_days > 0 else 0,
            "enable": True,
            "tgId": "",
            "subId": ""
        }
        clients.append(new_client)
        settings_json["clients"] = clients

        # Update inbound
        payload = {
            "up": inbound.get("up", 0),
            "down": inbound.get("down", 0),
            "total": inbound.get("total", 0),
            "remark": inbound.get("remark", ""),
            "enable": inbound.get("enable", True),
            "expiryTime": inbound.get("expiryTime", 0),
            "listen": inbound.get("listen", ""),
            "port": inbound.get("port", 443),
            "protocol": inbound.get("protocol", "vless"),
            "settings": json.dumps(settings_json),
            "streamSettings": inbound.get("streamSettings", "{}"),
            "sniffing": inbound.get("sniffing", "{}"),
            "allocate": inbound.get("allocate", "{}"),
        }

        data = await self._request("POST", f"/panel/api/inbounds/update/{inbound_id}", json=payload)
        return data

    async def remove_client(self, inbound_id: int, email: str) -> bool:
        data = await self._request("POST", f"/panel/api/inbounds/delClient/{inbound_id}", 
                                    data={"email": email})
        return data is not None and data.get("success", False)

    async def get_client_traffic(self, inbound_id: int, email: str) -> Dict[str, float]:
        data = await self._request("POST", f"/panel/api/inbounds/getClientTraffics/{inbound_id}")
        if data and data.get("success"):
            traffics = data.get("obj", [])
            for t in traffics:
                if t.get("email") == email:
                    return {
                        "up": t.get("up", 0),
                        "down": t.get("down", 0),
                        "total": t.get("total", 0)
                    }
        return {"up": 0, "down": 0, "total": 0}

    async def get_server_status(self) -> Dict[str, Any]:
        data = await self._request("POST", "/server/status")
        if data and data.get("success"):
            return data.get("obj", {})
        return {}

    def generate_vless_link(self, uuid_str: str, server: str, port: int = 443) -> str:
        return (
            f"vless://{uuid_str}@{server}:{port}?"
            f"type=tcp&security=reality&pbk={settings.XRAY_PUBLIC_KEY}"
            f"&fp=chrome&sni={settings.XRAY_SERVER_NAME}"
            f"&sid={settings.XRAY_SHORT_ID}&spx=%2F&flow=xtls-rprx-vision"
            f"#{server}"
        )

    async def close(self):
        await self.client.aclose()


xray_client = XrayPanelClient()
