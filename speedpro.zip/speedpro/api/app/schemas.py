from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime
from decimal import Decimal


class ResponseWrapper(BaseModel):
    success: bool = True
    data: Optional[dict] = None
    error: Optional[str] = None


# ========== AUTH ==========
class TelegramAuthRequest(BaseModel):
    init_data: str
    referral_code: Optional[str] = None


class AuthResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"


# ========== USER ==========
class UserProfile(BaseModel):
    id: int
    username: Optional[str]
    first_name: Optional[str]
    balance_rub: Decimal
    balance_stars: int
    referral_code: Optional[str]
    created_at: datetime

    class Config:
        from_attributes = True


# ========== TARIFFS ==========
class Tariff(BaseModel):
    plan_type: str
    title_ru: str
    duration_days: int
    price_rub: int
    price_stars: int
    devices: List[int]


TARIFFS = [
    Tariff(plan_type="1day", title_ru="1 день", duration_days=1, price_rub=39, price_stars=29, devices=[1,2,3,4,5]),
    Tariff(plan_type="1month", title_ru="1 месяц", duration_days=30, price_rub=250, price_stars=184, devices=[1,2,3,4,5]),
    Tariff(plan_type="12month", title_ru="12 месяцев", duration_days=365, price_rub=1400, price_stars=1027, devices=[1,2,3,4,5]),
]


def get_tariff(plan_type: str) -> Optional[Tariff]:
    for t in TARIFFS:
        if t.plan_type == plan_type:
            return t
    return None


def calculate_price(plan_type: str, devices: int) -> tuple[int, int]:
    tariff = get_tariff(plan_type)
    if not tariff:
        return 0, 0

    base_rub = tariff.price_rub
    base_stars = tariff.price_stars

    # Price multiplier based on devices
    multipliers = {1: 1.0, 2: 1.2, 3: 1.4, 4: 1.6, 5: 1.8}
    mult = multipliers.get(devices, 1.0)

    return int(base_rub * mult), int(base_stars * mult)


# ========== SUBSCRIPTION ==========
class SubscriptionCreate(BaseModel):
    plan_type: str
    devices_count: int = Field(ge=1, le=5)
    payment_method: str  # telegram_stars, balance


class SubscriptionResponse(BaseModel):
    id: str
    status: str
    plan_type: str
    devices_count: int
    traffic_used_gb: float
    traffic_limit_gb: int
    expires_at: datetime
    config_link: Optional[str] = None

    class Config:
        from_attributes = True


# ========== PAYMENT ==========
class StarsPaymentRequest(BaseModel):
    plan_type: str
    devices_count: int = Field(ge=1, le=5)


class StarsPaymentResponse(BaseModel):
    payment_id: str
    invoice: dict


class PaymentSuccessRequest(BaseModel):
    payment_id: str
    telegram_payment_charge_id: str


# ========== VPN CONFIG ==========
class VPNConfigResponse(BaseModel):
    id: str
    email: str
    config_link: str
    server_address: str
    server_port: int
    status: str
    traffic_used: float
    traffic_limit: int
    created_at: datetime

    class Config:
        from_attributes = True


# ========== REFERRAL ==========
class ReferralStats(BaseModel):
    invited_count: int
    earned_rub: Decimal
    pending_rub: Decimal
    referral_link: str
    referral_link_web: str


# ========== GIFT ==========
class GiftCreateRequest(BaseModel):
    plan_type: str
    devices_count: int = Field(ge=1, le=5)
    quantity: int = Field(ge=1, le=100)


class GiftRedeemRequest(BaseModel):
    code: str


# ========== SUPPORT ==========
class SupportTicketCreate(BaseModel):
    subject: str
    message: str


class SupportTicketResponse(BaseModel):
    id: str
    subject: str
    message: str
    status: str
    admin_reply: Optional[str]
    created_at: datetime

    class Config:
        from_attributes = True


# ========== ADMIN ==========
class ServerStatsResponse(BaseModel):
    cpu_percent: float
    ram_percent: float
    ram_used_mb: float
    ram_total_mb: float
    disk_percent: float
    active_connections: int
    xray_status: bool
    created_at: datetime


class TrafficStatsResponse(BaseModel):
    daily_upload_gb: float
    daily_download_gb: float
    monthly_upload_gb: float
    monthly_download_gb: float
    total_users: int
    active_subscriptions: int
