import uuid
from datetime import datetime
from sqlalchemy import Column, String, Integer, Float, Boolean, DateTime, Text, ForeignKey, BigInteger, Numeric
from sqlalchemy.orm import relationship
from sqlalchemy.dialects.postgresql import UUID
from app.database import Base


class User(Base):
    __tablename__ = "users"

    id = Column(BigInteger, primary_key=True)
    username = Column(String(255), nullable=True)
    first_name = Column(String(255), nullable=True)
    last_name = Column(String(255), nullable=True)
    language_code = Column(String(10), default="ru")

    balance_rub = Column(Numeric(10, 2), default=0)
    balance_stars = Column(Integer, default=0)
    referral_code = Column(String(50), unique=True, nullable=True)
    referred_by = Column(BigInteger, ForeignKey("users.id"), nullable=True)

    is_active = Column(Boolean, default=True)
    is_admin = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    subscriptions = relationship("Subscription", back_populates="user", lazy="selectin")
    vpn_configs = relationship("VPNConfig", back_populates="user", lazy="selectin")
    payments = relationship("Payment", back_populates="user", lazy="selectin")
    referrals = relationship("Referral", foreign_keys="Referral.referrer_id", back_populates="referrer", lazy="selectin")
    support_tickets = relationship("SupportTicket", back_populates="user", lazy="selectin")


class Subscription(Base):
    __tablename__ = "subscriptions"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(BigInteger, ForeignKey("users.id"), nullable=False)
    plan_type = Column(String(50), nullable=False)
    devices_count = Column(Integer, default=1)

    status = Column(String(20), default="active")
    traffic_limit_gb = Column(Integer, default=100)
    traffic_used_gb = Column(Float, default=0)

    started_at = Column(DateTime, default=datetime.utcnow)
    expires_at = Column(DateTime, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="subscriptions")
    vpn_configs = relationship("VPNConfig", back_populates="subscription", lazy="selectin")


class VPNConfig(Base):
    __tablename__ = "vpn_configs"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(BigInteger, ForeignKey("users.id"), nullable=False)
    subscription_id = Column(UUID(as_uuid=True), ForeignKey("subscriptions.id"), nullable=False)

    email = Column(String(255), nullable=False)
    vless_uuid = Column(String(255), unique=True, nullable=False)
    config_link = Column(Text, nullable=False)

    server_address = Column(String(255), nullable=False)
    server_port = Column(Integer, default=443)

    traffic_up = Column(Float, default=0)
    traffic_down = Column(Float, default=0)
    traffic_total = Column(Float, default=0)

    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = relationship("User", back_populates="vpn_configs")
    subscription = relationship("Subscription", back_populates="vpn_configs")


class Payment(Base):
    __tablename__ = "payments"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(BigInteger, ForeignKey("users.id"), nullable=False)
    subscription_id = Column(UUID(as_uuid=True), ForeignKey("subscriptions.id"), nullable=True)

    amount_rub = Column(Numeric(10, 2), default=0)
    amount_stars = Column(Integer, default=0)
    payment_method = Column(String(50), nullable=False)
    status = Column(String(20), default="pending")

    telegram_payment_charge_id = Column(String(255), nullable=True)
    payload = Column(Text, nullable=True)

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = relationship("User", back_populates="payments")


class Referral(Base):
    __tablename__ = "referrals"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    referrer_id = Column(BigInteger, ForeignKey("users.id"), nullable=False)
    referred_id = Column(BigInteger, ForeignKey("users.id"), nullable=False)

    commission_rub = Column(Numeric(10, 2), default=0)
    commission_stars = Column(Integer, default=0)
    status = Column(String(20), default="pending")

    created_at = Column(DateTime, default=datetime.utcnow)

    referrer = relationship("User", foreign_keys=[referrer_id], back_populates="referrals")


class GiftCode(Base):
    __tablename__ = "gift_codes"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    code = Column(String(50), unique=True, nullable=False)
    plan_type = Column(String(50), nullable=False)
    devices_count = Column(Integer, default=1)

    is_redeemed = Column(Boolean, default=False)
    redeemed_by = Column(BigInteger, ForeignKey("users.id"), nullable=True)
    redeemed_at = Column(DateTime, nullable=True)

    created_by = Column(BigInteger, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class SupportTicket(Base):
    __tablename__ = "support_tickets"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(BigInteger, ForeignKey("users.id"), nullable=False)

    subject = Column(String(255), nullable=False)
    message = Column(Text, nullable=False)
    status = Column(String(20), default="open")

    admin_reply = Column(Text, nullable=True)
    replied_at = Column(DateTime, nullable=True)
    replied_by = Column(BigInteger, nullable=True)

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = relationship("User", back_populates="support_tickets")


class ServerStat(Base):
    __tablename__ = "server_stats"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    cpu_percent = Column(Float, default=0)
    ram_percent = Column(Float, default=0)
    ram_used_mb = Column(Float, default=0)
    ram_total_mb = Column(Float, default=0)
    disk_percent = Column(Float, default=0)
    active_connections = Column(Integer, default=0)
    xray_status = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
