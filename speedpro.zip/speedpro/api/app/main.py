from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.database import engine, Base
from app.routers import auth, users, tariffs, payments, vpn, referrals, gifts, support, admin

app = FastAPI(
    title="SpeedPRO VPN API",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
async def startup():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

@app.get("/api/v1/health")
async def health_check():
    return {"status": "ok"}

@app.get("/api/v1")
async def root():
    return {"message": "SpeedPRO VPN API", "version": "1.0.0"}

# Routers
app.include_router(auth.router, prefix="/api/v1")
app.include_router(users.router, prefix="/api/v1")
app.include_router(tariffs.router, prefix="/api/v1")
app.include_router(payments.router, prefix="/api/v1")
app.include_router(vpn.router, prefix="/api/v1")
app.include_router(referrals.router, prefix="/api/v1")
app.include_router(gifts.router, prefix="/api/v1")
app.include_router(support.router, prefix="/api/v1")
app.include_router(admin.router, prefix="/api/v1")
