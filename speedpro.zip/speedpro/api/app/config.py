from pydantic_settings import BaseSettings
from pydantic import Field
from typing import Optional, List


class Settings(BaseSettings):
    BOT_TOKEN: str = Field(..., description="Telegram Bot Token")
    ADMIN_IDS: str = Field("", description="Comma-separated admin Telegram IDs")

    DATABASE_URL: str = Field(
        "postgresql+asyncpg://vpnuser:changeme@db:5432/vpnbot",
        description="Async PostgreSQL URL"
    )
    DB_PASSWORD: str = Field("changeme", description="DB password")

    API_HOST: str = Field("0.0.0.0", description="API bind host")
    API_PORT: int = Field(8000, description="API port")
    SECRET_KEY: str = Field(..., description="JWT secret key (min 32 chars)")
    WEBAPP_BASE_URL: str = Field("https://your-domain.com", description="Mini App domain")

    XRAY_PANEL_URL: str = Field("http://77.42.77.60:2053", description="3X-UI panel URL")
    XRAY_PANEL_USERNAME: str = Field("admin", description="3X-UI username")
    XRAY_PANEL_PASSWORD: str = Field("", description="3X-UI password")
    XRAY_PUBLIC_KEY: str = Field("", description="REALITY public key")
    XRAY_SERVER_NAME: str = Field("yahoo.com", description="REALITY server name (SNI)")
    XRAY_SHORT_ID: str = Field("", description="REALITY short ID")
    XRAY_SERVER_DOMAIN: str = Field("", description="Xray server domain")
    XRAY_INBOUND_ID: int = Field(1, description="Inbound ID in 3X-UI")

    STARS_PAYMENT_PROVIDER_TOKEN: str = Field("", description="Stars provider token")

    MONITOR_ADMIN_IDS: str = Field("", description="Monitoring alert admin IDs")
    MONITOR_BOT_TOKEN: str = Field("", description="Monitoring bot token")

    REFERRAL_PERCENT: int = Field(10, description="Referral commission %")

    FREE_TRIAL_DAYS: int = Field(3, description="Free trial days")
    FREE_TRIAL_TRAFFIC_GB: int = Field(30, description="Free trial traffic GB")
    FREE_TRIAL_MAX_DEVICES: int = Field(1, description="Free trial max devices")

    DEBUG: bool = Field(False, description="Debug mode")
    LOG_LEVEL: str = Field("INFO", description="Log level")
    ENVIRONMENT: str = Field("production", description="Environment")

    @property
    def admin_ids_list(self) -> List[int]:
        if not self.ADMIN_IDS:
            return []
        return [int(x.strip()) for x in self.ADMIN_IDS.split(",") if x.strip()]

    @property
    def monitor_admin_ids_list(self) -> List[int]:
        if not self.MONITOR_ADMIN_IDS:
            return self.admin_ids_list
        return [int(x.strip()) for x in self.MONITOR_ADMIN_IDS.split(",") if x.strip()]

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        extra = "ignore"


settings = Settings()
